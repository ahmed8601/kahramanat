# Project Vision

## Purpose
Professional commercial PWA for Kahramana Baghdad, an authentic Iraqi restaurant operating in Bahrain with two physical locations.

## User Goals
- Browse authentic Iraqi menu items with bilingual descriptions
- Select nearest branch based on location
- Build order with cart persistence across sessions
- Submit order directly via WhatsApp with automatic formatting
- Access restaurant contact and location information instantly

## Mobile-First Intent
- Primary user interface is mobile (80%+ expected traffic)
- Thumb-friendly navigation and controls
- App-like experience without app store installation
- Offline menu browsing capability
- One-tap actions for call and WhatsApp

## Luxury Level
- Quiet luxury aesthetic (no loud patterns or gradients)
- Premium feel through restraint and elegance
- Gold accents used sparingly for emphasis
- Professional presentation matching high-end dining
- Sophisticated without being pretentious

## Tone
- Welcoming and warm (Iraqi hospitality)
- Professional and trustworthy
- Clear and direct (no marketing fluff)
- Respectful of both Arabic and English speakers
- Confidence in quality without overselling
