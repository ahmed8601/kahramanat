"use client";

import Image from 'next/image';
import React, { useState } from 'react';
import { useCart } from '../context/CartContext';
import { useLanguage } from '../context/LanguageContext';
import { getTranslation } from '../utils/translations';

export interface MenuItemData {
  id: string;
  category?: string;
  image: string;
  price?: number | null;
  priceLabel?: { [lang: string]: string };
  name: string | { [lang: string]: string };
  desc?: string | { [lang: string]: string };
}

interface MenuItemCardProps {
  item: MenuItemData;
  currency: string;
  language: 'en' | 'ar';
}

/**
 * Card component representing a single menu item. Data is passed
 * entirely through props; names, descriptions and prices are not
 * translated automatically because the JSON defines them. Only UI
 * elements like the add button and feedback messages are translated.
 */
const MenuItemCard: React.FC<MenuItemCardProps> = ({ item, currency, language }) => {
  const { addItem } = useCart();
  const [added, setAdded] = useState(false);

  // Resolve name and description based on language. Fallback to string if provided directly.
  const name = typeof item.name === 'object' ? item.name[language] : (item.name as any);
  const description =
    item.desc && typeof item.desc === 'object'
      ? item.desc[language]
      : (item.desc as any);
  // Determine price display. If price is provided use currency, otherwise use the price label in the current language.
  let priceDisplay = '';
  if (item.price !== undefined && item.price !== null) {
    // Display with three decimal places if needed
    const priceNum: number = typeof item.price === 'number' ? item.price : 0;
    priceDisplay = `${priceNum.toFixed(3)} ${currency}`;
  } else if (item.priceLabel && typeof item.priceLabel === 'object') {
    priceDisplay = item.priceLabel[language];
  }

  const handleAdd = () => {
    // Convert price to number or zero
    const priceNum = typeof item.price === 'number' ? item.price : 0;
    addItem({ id: item.id, name: name, price: priceNum, image: item.image });
    setAdded(true);
    setTimeout(() => setAdded(false), 1200);
  };

  return (
    <div className="menu-card">
      <div className="image-wrapper">
        {/* Prefix image paths that do not start with a slash so they resolve from the public root. */}
        <Image
          src={item.image.startsWith('/') ? item.image : `/${item.image}`}
          alt={typeof item.name === 'object' ? (item.name as any)[language] : (item.name as any)}
          width={400}
          height={300}
          className="menu-image"
          priority={false}
        />
      </div>
      <h3 className="menu-title">{name}</h3>
      {description && (
        <p className="menu-description">{description}</p>
      )}
      <div className="menu-footer">
        <span className="menu-price">{priceDisplay}</span>
        <button className="add-btn" onClick={handleAdd} aria-label="add to cart">
          {getTranslation(language, ['menu', 'addToCart'])}
        </button>
      </div>
      {added && (
        <span className="add-feedback">
          {getTranslation(language, ['menu', 'added'])}
        </span>
      )}
      <style jsx>{`
        .menu-card {
          display: flex;
          flex-direction: column;
          background-color: var(--color-surface);
          border-radius: 8px;
          overflow: hidden;
          position: relative;
          transition: transform 0.2s ease;
        }
        .menu-card:active {
          transform: scale(0.96);
        }
        .image-wrapper {
          position: relative;
          width: 100%;
          height: 0;
          padding-bottom: 65%;
        }
        .menu-image {
          object-fit: cover;
        }
        .menu-title {
          font-size: 1.1rem;
          font-weight: 600;
          margin: 0.5rem 0.75rem 0;
          color: var(--color-text-primary);
        }
        .menu-description {
          flex-grow: 1;
          font-size: 0.9rem;
          margin: 0.25rem 0.75rem;
          color: var(--color-text-secondary);
          line-height: 1.4;
        }
        .menu-footer {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 0.5rem 0.75rem 0.75rem;
        }
        .menu-price {
          font-size: 1rem;
          font-weight: 500;
          color: var(--color-gold-primary);
        }
        .add-btn {
          background-color: var(--color-gold-primary);
          color: var(--color-dark-brown);
          border: none;
          padding: 0.4rem 0.8rem;
          border-radius: 4px;
          cursor: pointer;
          font-size: 0.9rem;
          font-weight: 600;
          transition: transform 0.1s ease;
        }
        .add-btn:active {
          transform: scale(0.96);
        }
        .add-feedback {
          position: absolute;
          bottom: 0.5rem;
          left: 50%;
          transform: translateX(-50%);
          background-color: rgba(0, 0, 0, 0.6);
          padding: 0.25rem 0.5rem;
          border-radius: 4px;
          font-size: 0.8rem;
          color: var(--color-gold-primary);
          pointer-events: none;
        }
      `}</style>
    </div>
  );
};

export default MenuItemCard;