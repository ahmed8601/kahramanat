"use client";

import React, { useEffect, useState } from 'react';
import MenuItemCard from './MenuItemCard';
import { useLanguage } from '../context/LanguageContext';
import { getTranslation } from '../utils/translations';

/**
 * Section component for the restaurant menu. It loads menu items from
 * the public menu.json file. If no items exist the section shows a
 * friendly message indicating that the curated menu will be available
 * soon. No items are hard‑coded; everything is read from the JSON at
 * runtime.
 */
const MenuSection: React.FC = () => {
  const { language } = useLanguage();
  // Hold the full menu data from the JSON including categories, dishes and currency
  const [menuData, setMenuData] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Fetch menu data from the public JSON file. If the file does not
    // exist or contains invalid JSON, fall back to an empty array.
    fetch('/menu.json')
      .then(res => res.json())
      .then(data => {
        // Expecting an object with categories, dishes and currency
        if (data && typeof data === 'object') {
          setMenuData(data);
        } else {
          setMenuData(null);
        }
      })
      .catch(() => {
        setMenuData(null);
      })
      .finally(() => setLoading(false));
  }, []);

  const hasData = menuData && Array.isArray(menuData.categories) && Array.isArray(menuData.dishes);

  return (
    <section id="menu" className="section menu-section">
      <h2 className="section-title">
        {getTranslation(language, ['menu', 'title'])}
      </h2>
      {loading ? (
        <p className="coming-soon">…</p>
      ) : hasData ? (
        <div className="menu-wrapper">
          {menuData.categories.map((cat: any) => {
            // Filter dishes belonging to this category
            const dishes = menuData.dishes.filter((dish: any) => dish.category === cat.id);
            if (dishes.length === 0) return null;
            return (
                <div key={cat.id} className="menu-category" dir={language === 'ar' ? 'rtl' : 'ltr'}>
                <h3 className="category-title">{cat[language]}</h3>
                <div className="menu-grid">
                  {dishes.map((dish: any) => (
                    <MenuItemCard
                      key={dish.id}
                      item={dish}
                      currency={menuData.currency || 'BD'}
                      language={language}
                    />
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <p className="coming-soon">
          {getTranslation(language, ['menu', 'empty'])}
        </p>
      )}
      <style jsx>{`
        .menu-section {
          padding: 4rem 1rem;
          background-color: var(--color-background-main);
        }
        .section-title {
          text-align: center;
          margin-bottom: 2rem;
          color: var(--color-gold-primary);
          font-size: 2rem;
          font-weight: 600;
        }
        .menu-wrapper {
          max-width: 1200px;
          margin: 0 auto;
        }
        .menu-category {
          margin-bottom: 3rem;
        }
        .category-title {
          margin: 2rem 0 1rem;
          color: var(--color-gold-primary);
          font-size: 1.6rem;
          font-weight: 600;
          text-align: inherit;
        }
        .menu-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(230px, 1fr));
          gap: 1.2rem;
        }
        .coming-soon {
          text-align: center;
          color: var(--color-text-secondary);
          font-size: 1rem;
        }
      `}</style>
    </section>
  );
};

export default MenuSection;